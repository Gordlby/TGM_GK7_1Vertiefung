from django.contrib import admin
from .models import Fach, Antwort

# Register your models here.
admin.site.register(Fach)
admin.site.register(Antwort)